﻿using ContactApp.Models;

namespace ContactApp.DataAccess
{
    public class ContactService:IContactService<ContactInfo>
    {
        public static List<ContactInfo> contacts = new List<ContactInfo>
        {
            new ContactInfo { ContactId = 101, FirstName = "shiva", LastName = "prasad", CompanyName = "UpGrad", EmailId = "shivaprasad@gmail.com", MobileNo = 0123456789, Designation = "Junior Software Engineer" },
            new ContactInfo { ContactId = 102, FirstName = "Mohan", LastName = "krishna", CompanyName = "Cognizant", EmailId = "mohan@gmail.com", MobileNo = 9955468223, Designation = "QA Tester" },
            new ContactInfo { ContactId = 103, FirstName = "Nikhil", LastName = "Kumar", CompanyName = "Accenture", EmailId = "nikhilkumar@gmail.com", MobileNo = 8546727890, Designation = "Delivery Manager" },
            new ContactInfo { ContactId = 104, FirstName = "charan", LastName = "kumar", CompanyName = "Infosys", EmailId = "jane@xyz.com", MobileNo = 9542635958, Designation = "Developer" }
        };

        public bool AddContact(ContactInfo entity)  // add contacts
        {
            contacts.Add(entity);
            return true;
        }

        public bool DeleteContact(int? id)  //delete contacts
        {
            var ContactById = contacts.FirstOrDefault(con => con.ContactId.Equals(id));
            if (ContactById != null)
            {
                contacts.Remove(ContactById);
                return true;
            }
            else
            {
                return false;
            }
        }

        public bool UpdateContact(ContactInfo entity)  //update contact
        {
            var ExistingContact = contacts.FirstOrDefault(con => con.ContactId.Equals(entity.ContactId));
            if (ExistingContact != null)
            {
                ExistingContact.ContactId = entity.ContactId;
                ExistingContact.FirstName = entity.FirstName;
                ExistingContact.LastName = entity.LastName;
                ExistingContact.CompanyName = entity.CompanyName;
                ExistingContact.EmailId = entity.EmailId;
                ExistingContact.MobileNo = entity.MobileNo;
                ExistingContact.Designation = entity.Designation;
                return true;
            }
            else
            {
                return false;
            }
        }

        public List<ContactInfo> ShowContacts()  //show contact
        {
            return contacts;
        }

        public ContactInfo searchContactById(int? id)  //search by contact id
        {
            var ContactById = contacts.FirstOrDefault(con=>con.ContactId.Equals(id));
            return ContactById;
        }

        public ContactInfo searchContactByName(string? Name)  //search by name
        {
            var ContactByName = contacts.FirstOrDefault(con=>con.FirstName.Equals(Name));
            return ContactByName;
        }

        public bool UpdateContact(int contactId)
        {
            throw new NotImplementedException();
        }
    }
}
