﻿namespace ContactApp.DataAccess
{
    public interface IContactService<TEntity>
    {
        List<TEntity> ShowContacts();
        bool DeleteContact(int? id);
        bool UpdateContact(TEntity entity);
        bool AddContact(TEntity entiry);
        TEntity searchContactById(int? id);
        TEntity searchContactByName(string? Name);
        bool UpdateContact(int contactId);
    }
}
