﻿using ContactApp.DataAccess;
using ContactApp.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;

namespace ContactApp.Controllers
{
    [Route("Contact")]
    public class ContactInfoController : Controller
    {
        private readonly IContactService<ContactInfo> _contactService;
        private string? GetById;

        public string? GetByName { get; private set; }

        public ContactInfoController(IContactService<ContactInfo> contactService)
        {
            this._contactService = contactService;
        }

        [Route("/")]    //Start-upp route
        [Route("List",Name ="List")]
        public IActionResult ContactListPage()    //contact list page
        {
            var contacts = _contactService.ShowContacts();
            return View(contacts);
        }


        [Route("GetById/{id?}",Name ="GetById")]
        public IActionResult SearchContactByIdPage(int? id)  //search by contact id
        {
            var ContactById = _contactService.searchContactById(id);
            if(ContactById != null)
            {
                return View(ContactById);
            }
            else
            {
                return NotFound();  //404 error
            }
        }

        [Route("GetByName/{Name?}",Name ="GetByName")]
        public IActionResult SearchContactByNamePage(string? name)
        {
            var GetByName = _contactService.searchContactByName(name);
            if (GetByName != null)
            {
                return View(GetByName);
            }
            else
            {
                return NotFound();
            }
        }


        [HttpGet]
        [Route("AddContact",Name ="AddContact")]
        public IActionResult AddContact()  //Adding Contact(Http Get)
        {
            LoadDesignations();
            return View();
        }


        [HttpPost]
        [Route("SaveContact",Name ="SaveContact")]
        public IActionResult AddContact(ContactInfo contactinfo)  //Http Post Add Contact
        {
            if (ModelState.IsValid)
            {
                var isExist = _contactService.searchContactById(contactinfo.ContactId);
                if (isExist == null)
                {
                    var isSaved = _contactService.AddContact(contactinfo);
                    if (isSaved)
                    {
                        return RedirectToRoute("List");
                    }
                    else
                    {
                        LoadDesignations();
                        return BadRequest();
                    }
                }
                else
                {
                    ModelState.AddModelError("ContactId", "Contact Id Already Exist");
                    LoadDesignations();
                    return View();
                }
            }
            else
            {
                LoadDesignations();
                return View();
            }
        }


        [HttpGet]
        [Route("DelectContact",Name ="DelectContact")]
        public IActionResult DelectContact(int? id)
        {
            var GetById = _contactService.searchContactById(id);
            if (GetById != null)
            {
                return View(GetById);
            }
            else
            {
                return NotFound();
            }
        }




        [HttpPost]
        [Route("RemoveContact",Name ="RemoveContact")]
        public IActionResult DelectContact(ContactInfo contact)
        {
            var isDeleted = _contactService.DeleteContact(contact.ContactId);
            if (isDeleted)
            {
                return RedirectToRoute("List");
            }
            else
            {
                return BadRequest();
            }
        }


        [HttpGet]
        [Route("EditContact",Name ="EditContact")]
        public IActionResult EditContact(int? id)
        {
            var GetByName = _contactService.searchContactById(id);
            if(GetByName != null)
            {
                LoadDesignations();
                return View(GetByName);
            }
            else
            {
                return NotFound();
            }
        }


        [HttpPost]
        [Route("Update",Name ="Update")]
        public IActionResult EditContact(ContactInfo contact)
        {
            var isUpdated = _contactService.UpdateContact(contact);
            if (isUpdated)
            {
                return RedirectToRoute("List");
            }
            LoadDesignations();
            return View(contact);
        }

        [HttpGet]
        [Route("Details", Name = "Details")]
        public IActionResult ContactDetails(int? id)
        {
            var ShowDetails = _contactService.searchContactById(id);
            if (ShowDetails != null)
            {
                //LoadDesignations();
                return View(ShowDetails);
            }
            else
            {
                return NotFound();
            }
        }

        [NonAction]
        public void LoadDesignations()
        {
            var designations = new List<SelectListItem>
            {
                new SelectListItem{Text="Manager",Value="Manager"},
                new SelectListItem{Text="junior Software Engineer",Value="junior Software Engineer"},
                new SelectListItem{Text="Developer",Value="Developer"},
                new SelectListItem{Text="Tester",Value="Tester"},
                new SelectListItem{Text="Support",Value="Support"},
                new SelectListItem{Text="Intern",Value="Intern"}
            }; 
            ViewBag.ContactDesignation = designations;
        }
    }
}
