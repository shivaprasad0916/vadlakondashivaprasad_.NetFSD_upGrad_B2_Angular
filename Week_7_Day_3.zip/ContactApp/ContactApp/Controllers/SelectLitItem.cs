﻿using Microsoft.AspNetCore.Mvc.Rendering;

namespace ContactApp.Controllers
{
    internal class SelectLitItem : SelectListItem
    {
        public string Text { get; set; }
        public string Value { get; set; }
    }
}