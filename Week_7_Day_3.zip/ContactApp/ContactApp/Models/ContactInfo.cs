﻿using System.ComponentModel.DataAnnotations;
namespace ContactApp.Models
{
    public class ContactInfo
    {
        [Required(AllowEmptyStrings =false,ErrorMessage ="Contact Id can not be Null")]
        [Range(minimum:100,maximum:1000, ErrorMessage ="Contact Id only between 100-1000 only")]
        [RegularExpression(pattern:"^[0-9]*$")]
        public int ContactId {  get; set; }


        [Required(AllowEmptyStrings = false, ErrorMessage = "Contact First Name can not be Null")]
        public string? FirstName {  get; set; }


        [Required(AllowEmptyStrings = false, ErrorMessage = "Contact Last Name can not be Null")]
        public string? LastName {  get; set; }


        [Required(AllowEmptyStrings = false, ErrorMessage = "Company Name can not be Null")]
        public string? CompanyName {  get; set; }


        [Required(AllowEmptyStrings = false, ErrorMessage = "Email Id can not be Null")]
        [DataType(DataType.EmailAddress, ErrorMessage ="Invalid Email")]
        public string? EmailId {  get; set; }


        [Required(AllowEmptyStrings = false, ErrorMessage = "Mobile Nummber can not be Null")]
        [DataType(DataType.PhoneNumber, ErrorMessage ="Invalid Number")]
        public long MobileNo {  get; set; }


        [Required(AllowEmptyStrings = false, ErrorMessage = "Designation can not be Null")]
        public string? Designation {  get; set; }
    }
}
