
[ApiController]
[Route("api/[controller]")]
public class ContactsController:ControllerBase{
    private readonly ContactService _service;
    public ContactsController(ContactService s){_service=s;}
    [HttpGet]
    public IActionResult Get()=>Ok(_service.GetAll());
}
