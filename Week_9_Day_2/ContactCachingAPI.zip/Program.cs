
var builder = WebApplication.CreateBuilder(args);
builder.Services.AddMemoryCache();
builder.Services.AddSingleton<ContactRepository>();
builder.Services.AddScoped<ContactService>();
builder.Services.AddControllers();
var app = builder.Build();
app.MapControllers();
app.Run();
