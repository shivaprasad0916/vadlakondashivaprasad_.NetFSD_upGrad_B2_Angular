
public class ContactService {
    private readonly IMemoryCache _cache;
    private readonly ContactRepository _repo;
    public ContactService(IMemoryCache cache, ContactRepository repo){
        _cache=cache; _repo=repo;
    }
    public List<Contact> GetAll(){
        return _cache.GetOrCreate("list", e=>{
            e.AbsoluteExpirationRelativeToNow=TimeSpan.FromSeconds(60);
            return _repo.GetAll();
        });
    }
}
