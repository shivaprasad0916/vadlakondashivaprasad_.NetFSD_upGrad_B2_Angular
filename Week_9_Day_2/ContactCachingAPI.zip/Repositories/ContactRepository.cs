
public class ContactRepository {
    private static List<Contact> contacts = new() {
        new Contact{Id=1,Name="John",Email="john@test.com"},
        new Contact{Id=2,Name="Sara",Email="sara@test.com"}
    };
    public List<Contact> GetAll()=>contacts;
    public Contact GetById(int id)=>contacts.FirstOrDefault(x=>x.Id==id);
}
