
using Microsoft.AspNetCore.RateLimiting;
using System.Threading.RateLimiting;

var builder = WebApplication.CreateBuilder(args);
builder.Services.AddRateLimiter(o=>{
    o.AddFixedWindowLimiter("fixed",opt=>{
        opt.PermitLimit=5;
        opt.Window=TimeSpan.FromSeconds(60);
    });
});
builder.Services.AddControllers();
var app=builder.Build();
app.UseRateLimiter();
app.MapControllers().RequireRateLimiting("fixed");
app.Run();
