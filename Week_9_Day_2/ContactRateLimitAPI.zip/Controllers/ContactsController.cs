
[ApiController]
[Route("api/[controller]")]
public class ContactsController:ControllerBase{
    [HttpGet]
    public IActionResult Get()=>Ok("Allowed");
}
