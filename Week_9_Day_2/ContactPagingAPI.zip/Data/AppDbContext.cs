
public class AppDbContext:DbContext{
    public AppDbContext(DbContextOptions opt):base(opt){}
    public DbSet<Contact> Contacts {get;set;}
}
