
public class ContactService{
    private readonly AppDbContext _ctx;
    public ContactService(AppDbContext ctx){_ctx=ctx;}
    public object Get(int page,int size){
        var data=_ctx.Contacts.AsQueryable();
        var total=data.Count();
        var result=data.Skip((page-1)*size).Take(size).ToList();
        return new{total, data=result};
    }
}
