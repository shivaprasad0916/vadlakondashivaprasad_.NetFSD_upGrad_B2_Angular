
[ApiController]
[Route("api/[controller]")]
public class ContactsController:ControllerBase{
    private readonly ContactService _s;
    public ContactsController(ContactService s){_s=s;}
    [HttpGet]
    public IActionResult Get(int page=1,int size=5){
        return Ok(_s.Get(page,size));
    }
}
