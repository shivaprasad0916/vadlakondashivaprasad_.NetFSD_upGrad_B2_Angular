
var builder = WebApplication.CreateBuilder(args);
builder.Services.AddDbContext<AppDbContext>(o=>o.UseInMemoryDatabase("db"));
builder.Services.AddScoped<ContactService>();
builder.Services.AddControllers();
var app = builder.Build();
app.MapControllers();
app.Run();
