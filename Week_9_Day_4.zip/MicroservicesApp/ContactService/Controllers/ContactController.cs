using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using ContactService.Models;
using ContactService.Services;

namespace ContactService.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    [Authorize] // All endpoints require authentication
    public class ContactController : ControllerBase
    {
        private readonly IContactService _contactService;

        public ContactController(IContactService contactService)
        {
            _contactService = contactService;
        }

        /// <summary>Get all contacts - Admin and User allowed</summary>
        [HttpGet]
        [Authorize(Roles = "Admin,User")]
        public async Task<IActionResult> GetAll()
        {
            var contacts = await _contactService.GetAllContactsAsync();
            return Ok(contacts);
        }

        /// <summary>Get contact by ID - Admin and User allowed</summary>
        [HttpGet("{id:int}")]
        [Authorize(Roles = "Admin,User")]
        public async Task<IActionResult> GetById(int id)
        {
            var contact = await _contactService.GetContactByIdAsync(id);
            if (contact == null) return NotFound(new { message = $"Contact with ID {id} not found." });
            return Ok(contact);
        }

        /// <summary>Create a new contact - Admin only</summary>
        [HttpPost]
        [Authorize(Roles = "Admin")]
        public async Task<IActionResult> Create([FromBody] CreateContactRequest request)
        {
            if (!ModelState.IsValid) return BadRequest(ModelState);

            var created = await _contactService.CreateContactAsync(request);
            return CreatedAtAction(nameof(GetById), new { id = created.ContactId }, created);
        }

        /// <summary>Update a contact - Admin only</summary>
        [HttpPut("{id:int}")]
        [Authorize(Roles = "Admin")]
        public async Task<IActionResult> Update(int id, [FromBody] UpdateContactRequest request)
        {
            if (!ModelState.IsValid) return BadRequest(ModelState);

            var updated = await _contactService.UpdateContactAsync(id, request);
            if (updated == null) return NotFound(new { message = $"Contact with ID {id} not found." });
            return Ok(updated);
        }

        /// <summary>Delete a contact - Admin only</summary>
        [HttpDelete("{id:int}")]
        [Authorize(Roles = "Admin")]
        public async Task<IActionResult> Delete(int id)
        {
            var deleted = await _contactService.DeleteContactAsync(id);
            if (!deleted) return NotFound(new { message = $"Contact with ID {id} not found." });
            return Ok(new { message = $"Contact with ID {id} deleted successfully." });
        }
    }
}
