using ContactService.Models;
using ContactService.Repositories;

namespace ContactService.Services
{
    public class ContactServiceImpl : IContactService
    {
        private readonly IContactRepository _repository;

        public ContactServiceImpl(IContactRepository repository)
        {
            _repository = repository;
        }

        public async Task<IEnumerable<Contact>> GetAllContactsAsync()
            => await _repository.GetAllAsync();

        public async Task<Contact?> GetContactByIdAsync(int id)
            => await _repository.GetByIdAsync(id);

        public async Task<Contact> CreateContactAsync(CreateContactRequest request)
        {
            var contact = new Contact
            {
                Name = request.Name,
                Email = request.Email,
                Phone = request.Phone,
                CategoryId = request.CategoryId
            };
            return await _repository.CreateAsync(contact);
        }

        public async Task<Contact?> UpdateContactAsync(int id, UpdateContactRequest request)
        {
            var existing = await _repository.GetByIdAsync(id);
            if (existing == null) return null;

            var updated = new Contact
            {
                Name = request.Name ?? existing.Name,
                Email = request.Email ?? existing.Email,
                Phone = request.Phone ?? existing.Phone,
                CategoryId = request.CategoryId ?? existing.CategoryId
            };
            return await _repository.UpdateAsync(id, updated);
        }

        public async Task<bool> DeleteContactAsync(int id)
            => await _repository.DeleteAsync(id);
    }
}
