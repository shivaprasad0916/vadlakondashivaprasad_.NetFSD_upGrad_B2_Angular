using ContactService.Models;

namespace ContactService.Services
{
    public interface IContactService
    {
        Task<IEnumerable<Contact>> GetAllContactsAsync();
        Task<Contact?> GetContactByIdAsync(int id);
        Task<Contact> CreateContactAsync(CreateContactRequest request);
        Task<Contact?> UpdateContactAsync(int id, UpdateContactRequest request);
        Task<bool> DeleteContactAsync(int id);
    }
}
