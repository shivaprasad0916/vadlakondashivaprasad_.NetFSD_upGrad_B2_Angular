using System.ComponentModel.DataAnnotations;

namespace CategoryService.Models
{
    public class Category
    {
        [Key]
        public int CategoryId { get; set; }

        [Required]
        [MaxLength(100)]
        public string CategoryName { get; set; } = string.Empty;

        [MaxLength(500)]
        public string Description { get; set; } = string.Empty;
    }

    public class CreateCategoryRequest
    {
        [Required]
        [MaxLength(100)]
        public string CategoryName { get; set; } = string.Empty;

        [MaxLength(500)]
        public string Description { get; set; } = string.Empty;
    }

    public class UpdateCategoryRequest
    {
        [MaxLength(100)]
        public string? CategoryName { get; set; }

        [MaxLength(500)]
        public string? Description { get; set; }
    }
}
