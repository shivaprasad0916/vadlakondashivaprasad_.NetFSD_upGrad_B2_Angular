using CategoryService.Models;
using CategoryService.Repositories;

namespace CategoryService.Services
{
    public class CategoryServiceImpl : ICategoryService
    {
        private readonly ICategoryRepository _repository;

        public CategoryServiceImpl(ICategoryRepository repository)
        {
            _repository = repository;
        }

        public async Task<IEnumerable<Category>> GetAllCategoriesAsync()
            => await _repository.GetAllAsync();

        public async Task<Category?> GetCategoryByIdAsync(int id)
            => await _repository.GetByIdAsync(id);

        public async Task<Category> CreateCategoryAsync(CreateCategoryRequest request)
        {
            var category = new Category
            {
                CategoryName = request.CategoryName,
                Description = request.Description
            };
            return await _repository.CreateAsync(category);
        }

        public async Task<Category?> UpdateCategoryAsync(int id, UpdateCategoryRequest request)
        {
            var existing = await _repository.GetByIdAsync(id);
            if (existing == null) return null;

            var updated = new Category
            {
                CategoryName = request.CategoryName ?? existing.CategoryName,
                Description = request.Description ?? existing.Description
            };
            return await _repository.UpdateAsync(id, updated);
        }

        public async Task<bool> DeleteCategoryAsync(int id)
            => await _repository.DeleteAsync(id);
    }
}
