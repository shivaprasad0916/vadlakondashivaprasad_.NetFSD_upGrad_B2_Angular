# Microservices App — Centralized Auth & Authorization with Ocelot API Gateway

## Week-9 (DAY-4) Hands-On — ASP.NET Core (.NET 8)

---

## Architecture Overview

```
Client
  │
  ▼
API Gateway (Port 5000)  ◄─── Ocelot: validates JWT, enforces roles, routes requests
  │
  ├──► Auth Service     (Port 5001)  ─── AuthDB     (SQL Server)
  ├──► Contact Service  (Port 5002)  ─── ContactDB  (SQL Server)
  └──► Category Service (Port 5003)  ─── CategoryDB (SQL Server)
```

---

## Project Structure

```
MicroservicesApp/
├── MicroservicesApp.sln
├── AuthService/
│   ├── Controllers/AuthController.cs
│   ├── Services/IAuthService.cs + AuthServiceImpl.cs
│   ├── Repositories/IUserRepository.cs + UserRepository.cs
│   ├── Models/User.cs
│   ├── Data/AuthDbContext.cs
│   └── appsettings.json          (Port 5001 | DB: AuthDB)
├── ContactService/
│   ├── Controllers/ContactController.cs
│   ├── Services/IContactService.cs + ContactServiceImpl.cs
│   ├── Repositories/IContactRepository.cs + ContactRepository.cs
│   ├── Models/Contact.cs
│   ├── Data/ContactDbContext.cs
│   └── appsettings.json          (Port 5002 | DB: ContactDB)
├── CategoryService/
│   ├── Controllers/CategoryController.cs
│   ├── Services/ICategoryService.cs + CategoryServiceImpl.cs
│   ├── Repositories/ICategoryRepository.cs + CategoryRepository.cs
│   ├── Models/Category.cs
│   ├── Data/CategoryDbContext.cs
│   └── appsettings.json          (Port 5003 | DB: CategoryDB)
└── ApiGateway/
    ├── Program.cs
    ├── ocelot.json               (Route config)
    └── appsettings.json          (Port 5000)
```

---

## Prerequisites

- [.NET 8 SDK](https://dotnet.microsoft.com/download/dotnet/8)
- SQL Server (LocalDB, Express, or full)
- Visual Studio 2022 / VS Code / Rider

---

## Setup & Run

### Step 1 — Update Connection Strings

Edit `appsettings.json` in **each** service if your SQL Server connection differs:

```json
"Server=localhost;Database=AuthDB;Trusted_Connection=True;TrustServerCertificate=True;"
```

Replace `localhost` with your SQL Server instance name (e.g., `.\SQLEXPRESS`).

---

### Step 2 — Restore & Build

```bash
cd MicroservicesApp
dotnet restore MicroservicesApp.sln
dotnet build MicroservicesApp.sln
```

---

### Step 3 — Run All Four Services

Open **4 separate terminals**:

```bash
# Terminal 1 — Auth Service (Port 5001)
cd AuthService
dotnet run

# Terminal 2 — Contact Service (Port 5002)
cd ContactService
dotnet run

# Terminal 3 — Category Service (Port 5003)
cd CategoryService
dotnet run

# Terminal 4 — API Gateway (Port 5000)
cd ApiGateway
dotnet run
```

> Databases are auto-created on first run via `EnsureCreated()`.

---

## API Endpoints

All requests go through the **API Gateway on port 5000**.

### Auth Endpoints (No Token Required)

| Method | URL                              | Description            |
|--------|----------------------------------|------------------------|
| POST   | `http://localhost:5000/api/auth/register` | Register user  |
| POST   | `http://localhost:5000/api/auth/login`    | Login, get JWT |

### Contact Endpoints (Token Required)

| Method | URL                                      | Role          |
|--------|------------------------------------------|---------------|
| GET    | `http://localhost:5000/api/contact`      | Admin, User   |
| GET    | `http://localhost:5000/api/contact/{id}` | Admin, User   |
| POST   | `http://localhost:5000/api/contact`      | Admin only    |
| PUT    | `http://localhost:5000/api/contact/{id}` | Admin only    |
| DELETE | `http://localhost:5000/api/contact/{id}` | Admin only    |

### Category Endpoints (Token Required)

| Method | URL                                       | Role          |
|--------|-------------------------------------------|---------------|
| GET    | `http://localhost:5000/api/category`      | Admin, User   |
| GET    | `http://localhost:5000/api/category/{id}` | Admin, User   |
| POST   | `http://localhost:5000/api/category`      | Admin only    |
| PUT    | `http://localhost:5000/api/category/{id}` | Admin only    |
| DELETE | `http://localhost:5000/api/category/{id}` | Admin only    |

---

## Demo Flow (Postman / curl)

### 1. Register an Admin user

```json
POST http://localhost:5000/api/auth/register
{
  "email": "admin@test.com",
  "password": "Admin@123",
  "role": "Admin"
}
```

### 2. Register a regular User

```json
POST http://localhost:5000/api/auth/register
{
  "email": "user@test.com",
  "password": "User@123",
  "role": "User"
}
```

### 3. Login and get JWT token

```json
POST http://localhost:5000/api/auth/login
{
  "email": "admin@test.com",
  "password": "Admin@123"
}
```

Response:
```json
{
  "token": "eyJhbGciOiJIUzI1NiIs...",
  "email": "admin@test.com",
  "role": "Admin",
  "message": "Login successful."
}
```

### 4. Access API without token → ❌ 401 Unauthorized

```
GET http://localhost:5000/api/contact
(No Authorization header)
→ 401 Unauthorized
```

### 5. Access API with token → ✅ Success

```
GET http://localhost:5000/api/contact
Authorization: Bearer eyJhbGciOiJIUzI1NiIs...
→ 200 OK
```

### 6. User role tries DELETE → ❌ 403 Forbidden

```
DELETE http://localhost:5000/api/contact/1
Authorization: Bearer <user-token>
→ 403 Forbidden
```

---

## Security Rules

| Rule                        | Detail                              |
|-----------------------------|-------------------------------------|
| JWT Secret Key              | Shared across all services          |
| Token expiry                | 24 hours                            |
| Login / Register            | Public — no token needed            |
| All other routes            | Protected — JWT required            |
| Admin role                  | Full CRUD access                    |
| User role                   | GET (read-only) access              |
| No shared databases         | Each service has its own DB         |
| No hardcoded tokens         | JWT generated at login dynamically  |

---

## Individual Swagger UIs (Direct Service Access)

Each service also has its own Swagger for testing directly (bypassing the gateway):

| Service          | Swagger URL                           |
|------------------|---------------------------------------|
| Auth Service     | http://localhost:5001/swagger         |
| Contact Service  | http://localhost:5002/swagger         |
| Category Service | http://localhost:5003/swagger         |

---

## Models

### User (AuthDB)
| Field        | Type   |
|--------------|--------|
| UserId       | int PK |
| Email        | string |
| PasswordHash | string |
| Role         | string (Admin/User) |

### Contact (ContactDB)
| Field      | Type   |
|------------|--------|
| ContactId  | int PK |
| Name       | string |
| Email      | string |
| Phone      | string |
| CategoryId | int    |

### Category (CategoryDB)
| Field        | Type   |
|--------------|--------|
| CategoryId   | int PK |
| CategoryName | string |
| Description  | string |
