
var builder = WebApplication.CreateBuilder(args);
builder.Services.AddControllers();
var app = builder.Build();
app.MapGet("/api/categories", () => new[] {
    new {Id=1, Name="Friends"},
    new {Id=2, Name="Work"}
});
app.Run();
