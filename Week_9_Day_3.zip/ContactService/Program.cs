
var builder = WebApplication.CreateBuilder(args);
builder.Services.AddControllers();
var app = builder.Build();
app.MapGet("/api/contacts", () => new[] {
    new {Id=1, Name="John"},
    new {Id=2, Name="Sara"}
});
app.Run();
