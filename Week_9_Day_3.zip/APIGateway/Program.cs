
var builder = WebApplication.CreateBuilder(args);
builder.Services.AddControllers();
var app = builder.Build();

app.MapGet("/api/contacts", () => "Forward to Contact Service");
app.MapGet("/api/categories", () => "Forward to Category Service");

app.Run();
