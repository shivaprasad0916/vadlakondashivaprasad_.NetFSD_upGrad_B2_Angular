using Microsoft.AspNetCore.Mvc;
using DataAccessLayer.Repository;
using DataAccessLayer.Models;

namespace AppUILayer.Controllers
{
    public class ContactController : Controller
    {
        private readonly IContactRepository _repo;

        public ContactController(IContactRepository repo)
        {
            _repo = repo;
        }

        public IActionResult Index()
        {
            var data = _repo.GetAllContacts();
            return View(data);
        }

        public IActionResult Create()
        {
            return View();
        }

        [HttpPost]
        public IActionResult Create(ContactInfo contact)
        {
            _repo.AddContact(contact);
            return RedirectToAction("Index");
        }

        public IActionResult Delete(int id)
        {
            _repo.DeleteContact(id);
            return RedirectToAction("Index");
        }
    }
}