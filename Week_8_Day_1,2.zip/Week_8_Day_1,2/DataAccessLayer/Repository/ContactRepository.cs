using Dapper;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using DataAccessLayer.Models;

namespace DataAccessLayer.Repository
{
    public class ContactRepository : IContactRepository
    {
        private readonly string connectionString = "YOUR_CONNECTION_STRING";

        private IDbConnection Connection => new SqlConnection(connectionString);

        public List<ContactInfo> GetAllContacts()
        {
            using var db = Connection;
            return db.Query<ContactInfo>("SELECT * FROM ContactInfo").AsList();
        }

        public ContactInfo GetContactById(int id)
        {
            using var db = Connection;
            return db.QueryFirstOrDefault<ContactInfo>("SELECT * FROM ContactInfo WHERE ContactId=@Id", new { Id = id });
        }

        public void AddContact(ContactInfo contact)
        {
            using var db = Connection;
            db.Execute("INSERT INTO ContactInfo(FirstName,LastName,EmailId,MobileNo,Designation,CompanyId,DepartmentId) VALUES(@FirstName,@LastName,@EmailId,@MobileNo,@Designation,@CompanyId,@DepartmentId)", contact);
        }

        public void UpdateContact(ContactInfo contact)
        {
            using var db = Connection;
            db.Execute("UPDATE ContactInfo SET FirstName=@FirstName,LastName=@LastName WHERE ContactId=@ContactId", contact);
        }

        public void DeleteContact(int id)
        {
            using var db = Connection;
            db.Execute("DELETE FROM ContactInfo WHERE ContactId=@Id", new { Id = id });
        }
    }
}