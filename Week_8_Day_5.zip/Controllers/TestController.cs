using Microsoft.AspNetCore.Mvc;
using ContactManagement.API.Exceptions;

namespace ContactManagement.API.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class TestController : ControllerBase
    {
        [HttpGet("error")]
        public IActionResult ThrowError()
        {
            throw new Exception("Test exception");
        }

        [HttpGet("notfound")]
        public IActionResult NotFoundError()
        {
            throw new NotFoundException("Contact not found");
        }
    }
}