using NUnit.Framework;
using ContactManagement;
using System.Collections.Generic;

namespace ContactManagement.Tests
{
    public class ContactServiceTests
    {
        private IContactService _service;

        [SetUp]
        public void Setup()
        {
            _service = new ContactService();
        }

        [Test]
        public void AddContact_ShouldAddContactSuccessfully()
        {
            // Arrange
            var contact = new Contact { Id = 1, Name = "Shiva", Email = "shiva@test.com" };

            // Act
            _service.AddContact(contact);
            var result = _service.GetAllContacts();

            // Assert
            Assert.IsNotNull(result);
            Assert.AreEqual(1, result.Count);
        }

        [Test]
        public void GetAllContacts_ShouldReturnNonEmptyList()
        {
            // Arrange
            _service.AddContact(new Contact { Id = 1, Name = "A", Email = "a@test.com" });

            // Act
            var result = _service.GetAllContacts();

            // Assert
            Assert.IsTrue(result.Count > 0);
        }

        [Test]
        public void GetContactById_ShouldReturnCorrectContact()
        {
            // Arrange
            var contact = new Contact { Id = 2, Name = "B", Email = "b@test.com" };
            _service.AddContact(contact);

            // Act
            var result = _service.GetContactById(2);

            // Assert
            Assert.IsNotNull(result);
            Assert.AreEqual("B", result.Name);
        }

        [Test]
        public void DeleteContact_ShouldRemoveContact()
        {
            // Arrange
            var contact = new Contact { Id = 3, Name = "C", Email = "c@test.com" };
            _service.AddContact(contact);

            // Act
            var result = _service.DeleteContact(3);
            var list = _service.GetAllContacts();

            // Assert
            Assert.IsTrue(result);
            Assert.AreEqual(0, list.Count);
        }
    }
}
