import { Component } from '@angular/core';
import { Contact } from '../models/contact.model';

@Component({
  selector: 'app-contact-list',
  templateUrl: './contact-list.component.html',
  styleUrls: ['./contact-list.component.css']
})
export class ContactListComponent {

  contacts: Contact[] = [
    { contactId: 1, name: 'Rahul Sharma', email: 'rahul@gmail.com', phone: '9876543210', isActive: true },
    { contactId: 2, name: 'Priya Singh', email: 'priya@gmail.com', phone: '9123456780', isActive: false },
    { contactId: 3, name: 'Amit Verma', email: 'amit@gmail.com', phone: '9988776655', isActive: true }
  ];

  searchText: string = '';
  filterStatus: string = 'all';

  get filteredContacts(): Contact[] {
    return this.contacts.filter(contact => {
      const matchesSearch = contact.name.toLowerCase().includes(this.searchText.toLowerCase());

      const matchesFilter =
        this.filterStatus === 'all' ||
        (this.filterStatus === 'active' && contact.isActive) ||
        (this.filterStatus === 'inactive' && !contact.isActive);

      return matchesSearch && matchesFilter;
    });
  }
}
