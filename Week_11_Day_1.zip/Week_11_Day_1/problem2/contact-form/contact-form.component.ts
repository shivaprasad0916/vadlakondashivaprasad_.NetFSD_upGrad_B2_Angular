import { Component } from '@angular/core';
import { Contact } from '../models/contact.model';

@Component({
  selector: 'app-contact-form',
  templateUrl: './contact-form.component.html',
  styleUrls: ['./contact-form.component.css']
})
export class ContactFormComponent {

  contacts: Contact[] = [];

  newContact: Contact = {
    contactId: 0,
    name: '',
    email: '',
    phone: '',
    isActive: false
  };

  onSubmit(form: any) {
    if (form.valid) {
      this.newContact.contactId = this.contacts.length + 1;
      this.contacts.push({ ...this.newContact });

      form.resetForm();

      this.newContact = {
        contactId: 0,
        name: '',
        email: '',
        phone: '',
        isActive: false
      };
    }
  }
}
