import { Component } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Contact } from '../models/contact.model';

@Component({
  selector: 'app-contact-reactive',
  templateUrl: './contact-reactive.component.html',
  styleUrls: ['./contact-reactive.component.css']
})
export class ContactReactiveComponent {

  contactForm: FormGroup;
  contacts: Contact[] = [];

  constructor(private fb: FormBuilder) {
    this.contactForm = this.fb.group({
      name: ['', Validators.required],
      email: ['', [Validators.required, Validators.email]],
      phone: ['', [Validators.required, Validators.minLength(10)]],
      isActive: [false]
    });
  }

  onSubmit() {
    if (this.contactForm.valid) {
      const newContact: Contact = {
        contactId: this.contacts.length + 1,
        ...this.contactForm.value
      };

      this.contacts.push(newContact);
      this.contactForm.reset();
    }
  }

  get f() {
    return this.contactForm.controls;
  }
}
