using ContactManagement.API.Models;

namespace ContactManagement.API.DataAccess
{
    public class ContactRepository : IContactRepository
    {
        private static List<ContactInfo> contacts = new List<ContactInfo>();
        private static int nextId = 1;

        public Task<List<ContactInfo>> GetAllAsync()
        {
            return Task.FromResult(contacts);
        }

        public Task<ContactInfo> GetByIdAsync(int id)
        {
            var contact = contacts.FirstOrDefault(x => x.ContactId == id);
            return Task.FromResult(contact);
        }

        public Task<ContactInfo> CreateAsync(ContactInfo contact)
        {
            contact.ContactId = nextId++;
            contacts.Add(contact);
            return Task.FromResult(contact);
        }

        public Task<bool> UpdateAsync(int id, ContactInfo contact)
        {
            var existing = contacts.FirstOrDefault(x => x.ContactId == id);
            if (existing == null) return Task.FromResult(false);

            existing.FirstName = contact.FirstName;
            existing.LastName = contact.LastName;
            existing.EmailId = contact.EmailId;
            existing.MobileNo = contact.MobileNo;
            existing.Designation = contact.Designation;
            existing.CompanyId = contact.CompanyId;
            existing.DepartmentId = contact.DepartmentId;

            return Task.FromResult(true);
        }

        public Task<bool> DeleteAsync(int id)
        {
            var contact = contacts.FirstOrDefault(x => x.ContactId == id);
            if (contact == null) return Task.FromResult(false);

            contacts.Remove(contact);
            return Task.FromResult(true);
        }
    }
}