using Microsoft.AspNetCore.Mvc;
using API.Models;

namespace API.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class ContactsController : ControllerBase
    {
        private static List<Contact> contacts = new List<Contact>();

        [HttpGet]
        public IActionResult GetAll() => Ok(contacts);

        [HttpPost]
        public IActionResult Create(Contact contact)
        {
            contacts.Add(contact);
            return Ok(contact);
        }
    }
}