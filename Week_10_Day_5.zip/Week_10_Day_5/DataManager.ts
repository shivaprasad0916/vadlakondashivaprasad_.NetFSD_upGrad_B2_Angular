function getFirstElement<T>(items: T[]):T{
    return items[0];
}

interface Repository<T>{
    add(items:T):void;
    getAll():T[];
}

class DataManager<T> implements Repository<T>{
    private items:T[]=[];
    add(item:T):void{
        this.items.push(item);
    }
    getAll():T[]{
        return this.items;
    }
}

interface User {
    id: number;
    name: string;
}

interface Product {
    id: number;
    title: string;
}

const userManager = new DataManager<User>();
userManager.add({ id: 1, name: "mohan" });
userManager.add({ id: 2, name: "rahul" });

const productManager = new DataManager<Product>();
productManager.add({ id: 101, title: "Laptop" });
productManager.add({ id: 102, title: "Mobile" });

const users = userManager.getAll();
console.log("Users:", users);

const products = productManager.getAll();
console.log("Products:", products)
console.log("First User:", getFirstElement(users));
console.log("First Product:", getFirstElement(products));