import { Student } from "./student.model";
import { formatName, calculateAverage } from "./utils";
import { getGrade, getTopper } from "./student.service";

// Sample data
const students: Student[] = [
    { id: 1, name: "john", marks: 85 },
    { id: 2, name: "alice", marks: 92 },
    { id: 3, name: "bob", marks: 70 }
];

// Format names
const formattedStudents = students.map(s => ({
    ...s,
    name: formatName(s.name)
}));

console.log("Formatted Students:", formattedStudents);

// Grades
formattedStudents.forEach(s => {
    console.log(`${s.name} Grade:`, getGrade(s.marks));
});

// Average
const avg = calculateAverage(formattedStudents);
console.log("Average Marks:", avg);

// Topper
const topper = getTopper(formattedStudents);
console.log("Topper:", topper);