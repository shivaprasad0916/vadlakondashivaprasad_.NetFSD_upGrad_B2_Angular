"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const utils_1 = require("./utils");
const student_service_1 = require("./student.service");
// Sample data
const students = [
    { id: 1, name: "john", marks: 85 },
    { id: 2, name: "alice", marks: 92 },
    { id: 3, name: "bob", marks: 70 }
];
// Format names
const formattedStudents = students.map(s => (Object.assign(Object.assign({}, s), { name: (0, utils_1.formatName)(s.name) })));
console.log("Formatted Students:", formattedStudents);
// Grades
formattedStudents.forEach(s => {
    console.log(`${s.name} Grade:`, (0, student_service_1.getGrade)(s.marks));
});
// Average
const avg = (0, utils_1.calculateAverage)(formattedStudents);
console.log("Average Marks:", avg);
// Topper
const topper = (0, student_service_1.getTopper)(formattedStudents);
console.log("Topper:", topper);
