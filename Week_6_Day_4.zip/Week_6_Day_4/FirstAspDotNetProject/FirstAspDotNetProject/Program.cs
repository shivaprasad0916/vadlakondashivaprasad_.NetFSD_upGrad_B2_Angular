var builder = WebApplication.CreateBuilder(args);
var mySetting = builder.Configuration["ConnectionStrings:MyConnection"];
var envName = "Development";

var app = builder.Build();
if (builder.Environment.IsStaging())
{
    envName = "Staging";
    app.UseDeveloperExceptionPage();
}
app.Run(async (context) =>
{
    // Write configuration settings to the HTTP response
    await context.Response.WriteAsync($"ENVIRONMENT:{envName} Welcome to My First ASP.NET Core App");

});

app.Run();
